/** Painting helpers shared by every ingredient paint function. */
import { centroid, inset } from "./primitives";
import type { Poly, Vec } from "./types";

export function tracePoly(ctx: CanvasRenderingContext2D, poly: Poly) {
  ctx.beginPath();
  const first = poly[0]!;
  ctx.moveTo(first.x, first.y);
  for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i]!.x, poly[i]!.y);
  ctx.closePath();
}

export function fillPoly(ctx: CanvasRenderingContext2D, poly: Poly, fill: string | CanvasGradient) {
  tracePoly(ctx, poly);
  ctx.fillStyle = fill;
  ctx.fill();
}

export function strokePoly(
  ctx: CanvasRenderingContext2D,
  poly: Poly,
  color: string,
  width: number,
) {
  tracePoly(ctx, poly);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineJoin = "round";
  ctx.stroke();
}

/** Paints the band between a polygon and its inset copy (skin / crust / rind). */
export function fillBand(
  ctx: CanvasRenderingContext2D,
  poly: Poly,
  thickness: number,
  fill: string | CanvasGradient,
) {
  const innerPoly = inset(poly, thickness).slice().reverse();
  ctx.beginPath();
  const a = poly[0]!;
  ctx.moveTo(a.x, a.y);
  for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i]!.x, poly[i]!.y);
  ctx.closePath();
  const b = innerPoly[0]!;
  ctx.moveTo(b.x, b.y);
  for (let i = 1; i < innerPoly.length; i++) ctx.lineTo(innerPoly[i]!.x, innerPoly[i]!.y);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill("evenodd");
}

export function radial(
  ctx: CanvasRenderingContext2D,
  c: Vec,
  r0: number,
  r1: number,
  stops: [number, string][],
  focus: Vec = c,
) {
  const g = ctx.createRadialGradient(focus.x, focus.y, r0, c.x, c.y, r1);
  for (const [t, col] of stops) g.addColorStop(t, col);
  return g;
}

export function linear(
  ctx: CanvasRenderingContext2D,
  a: Vec,
  b: Vec,
  stops: [number, string][],
) {
  const g = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
  for (const [t, col] of stops) g.addColorStop(t, col);
  return g;
}

/** Subtle painterly speckle constrained to the current clip. */
export function speckle(
  ctx: CanvasRenderingContext2D,
  poly: Poly,
  rnd: () => number,
  count: number,
  color: string,
  rMin: number,
  rMax: number,
  alpha = 0.25,
) {
  const c = centroid(poly);
  let maxR = 0;
  for (const p of poly) maxR = Math.max(maxR, Math.hypot(p.x - c.x, p.y - c.y));
  ctx.save();
  tracePoly(ctx, poly);
  ctx.clip();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  for (let i = 0; i < count; i++) {
    const a = rnd() * Math.PI * 2;
    const rr = Math.sqrt(rnd()) * maxR;
    const r = rMin + rnd() * (rMax - rMin);
    ctx.beginPath();
    ctx.ellipse(c.x + Math.cos(a) * rr, c.y + Math.sin(a) * rr, r, r * (0.6 + rnd() * 0.8), rnd() * 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/** Soft cozy highlight blob. */
export function highlight(
  ctx: CanvasRenderingContext2D,
  poly: Poly,
  at: Vec,
  r: number,
  color: string,
  alpha = 0.5,
) {
  ctx.save();
  tracePoly(ctx, poly);
  ctx.clip();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = radial(ctx, at, 0, r, [
    [0, color],
    [1, "rgba(255,255,255,0)"],
  ]);
  ctx.beginPath();
  ctx.ellipse(at.x, at.y, r, r * 0.8, -0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function withClip(ctx: CanvasRenderingContext2D, poly: Poly, draw: () => void) {
  ctx.save();
  tracePoly(ctx, poly);
  ctx.clip();
  draw();
  ctx.restore();
}
