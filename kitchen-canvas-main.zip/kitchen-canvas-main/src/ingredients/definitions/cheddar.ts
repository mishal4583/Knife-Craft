import { roundedRect } from "../primitives";
import { fillBand, fillPoly, highlight, linear, speckle, strokePoly, withClip } from "../paintUtils";
import { makeRng } from "../rng";
import type { IngredientDefinition } from "../types";

const colors = {
  cheese: "#e8942f",
  cheeseDeep: "#c9711b",
  cheesePale: "#f6c05e",
  cutFace: "#fbd27c",
  rind: "#b25e14",
  crumb: "#fde3ac",
};

export const cheddar: IngredientDefinition = {
  id: "cheddar",
  name: "Cheddar",
  category: "Dairy",
  seed: 4423,
  scale: 0.9,
  colors,
  seamColors: { edge: "#c9761f", inner: "#fbd88c" },
  techniques: ["Slice", "Dice", "Julienne", "Chop"],
  geometry: (seed) => {
    const rnd = makeRng(seed);
    // Dense block: rounded rect with hand-cut irregular edges.
    const body = roundedRect(0, 0.02, 1.52, 0.98, 1, 0.05, rnd);
    return {
      longAxis: 0,
      parts: [{ id: "body", kind: "body", poly: body, z: 0 }],
    };
  },
  paint: ({ ctx, geometry, rnd }) => {
    const body = geometry.parts.find((p) => p.id === "body")!.poly;

    fillPoly(
      ctx,
      body,
      linear(ctx, { x: -0.7, y: -0.5 }, { x: 0.7, y: 0.55 }, [
        [0, colors.cutFace],
        [0.4, colors.cheese],
        [1, colors.cheeseDeep],
      ]),
    );

    withClip(ctx, body, () => {
      // Lighter, matte cut face across the upper plane of the block.
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = linear(ctx, { x: 0, y: -0.5 }, { x: 0, y: 0.1 }, [
        [0, colors.cutFace],
        [1, "rgba(251,210,124,0)"],
      ]);
      ctx.fillRect(-0.9, -0.6, 1.8, 0.8);
      ctx.globalAlpha = 1;
      // Subtle pressed-curd striations.
      ctx.strokeStyle = "rgba(180,95,20,0.16)";
      ctx.lineWidth = 0.008;
      for (let i = 0; i < 22; i++) {
        const y = -0.5 + i * 0.05;
        ctx.beginPath();
        ctx.moveTo(-0.8, y + (rnd() - 0.5) * 0.02);
        ctx.lineTo(0.8, y + (rnd() - 0.5) * 0.02);
        ctx.stroke();
      }
      // Small natural imperfections / tiny eyes in the paste.
      for (let i = 0; i < 40; i++) {
        const x = (rnd() - 0.5) * 1.4;
        const y = (rnd() - 0.5) * 0.85;
        const r = 0.006 + rnd() * 0.014;
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = colors.cheeseDeep;
        ctx.beginPath();
        ctx.ellipse(x, y, r, r * 0.85, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 0.45;
        ctx.fillStyle = colors.crumb;
        ctx.beginPath();
        ctx.ellipse(x - r * 0.25, y - r * 0.3, r * 0.6, r * 0.5, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    });

    speckle(ctx, body, rnd, 150, colors.cheesePale, 0.004, 0.01, 0.18);
    fillBand(ctx, body, 0.03, "rgba(201,113,27,0.35)");
    fillBand(ctx, body, 0.012, colors.rind);
    highlight(ctx, body, { x: -0.35, y: -0.32 }, 0.4, "rgba(255,240,200,0.65)", 0.4);
    strokePoly(ctx, body, "rgba(140,68,10,0.45)", 0.012);
  },
};
